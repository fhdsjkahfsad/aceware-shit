#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include <stdlib.h>
#include <stdbool.h>
#include "esp_mac.h"

#define LED_PIN 2
#define DEBUG_PIN 23

int ledstatus = 0;
bool debug = false;
TaskHandle_t blinkTaskHandle = NULL; // Handle for the blink task

void blink(void* pvParameters);
void handleDebug(void* pvParameters);
void logTask(void* pvParameters);

void app_main(void) {
    xTaskCreate(blink, "Blink Onboard LED", 2048, NULL, 1, &blinkTaskHandle);
    xTaskCreate(handleDebug, "Handle Debug", 2048, NULL, 1, NULL);
    xTaskCreate(logTask, "Log Tasks", 2048, NULL, 1, NULL);
}

void blink(void* pvParameters) {
    gpio_set_direction(LED_PIN, GPIO_MODE_OUTPUT);
    while (1) {
        gpio_set_level(LED_PIN, 1);
        ledstatus = 1;
        vTaskDelay(pdMS_TO_TICKS(500));
        
        gpio_set_level(LED_PIN, 0);
        ledstatus = 0;
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

void handleDebug(void* pvParameters) {
    esp_rom_gpio_pad_select_gpio(DEBUG_PIN);
    gpio_set_direction(DEBUG_PIN, GPIO_MODE_INPUT);

    while (1) {
        int buttonState = gpio_get_level(DEBUG_PIN);
        if (buttonState == 1) {
            debug = true;
            printf("Debug detected, killing all tasks\n");
            vTaskDelete(blinkTaskHandle); // Correctly delete the blink task using its handle
            gpio_set_level(LED_PIN, 0);
            break; // Exit the loop after deleting the task
        }
        vTaskDelay(pdMS_TO_TICKS(100)); // Add a small delay to avoid busy-waiting
    }
}

void logTask(void* pvParameters) {
    while (1) {
        if (ledstatus == 1) {
            printf("LED ON\n");
        } else {
            printf("LED OFF\n");
        }

        if (debug == true) {
            printf("debug mode ON\n");
        } else {
            printf("debug mode OFF\n");
        }
        vTaskDelay(pdMS_TO_TICKS(10000)); // Log every second
    }
}
